package com.burgerclub.stafftracker.ui.employees

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.burgerclub.stafftracker.data.db.AppDatabase
import com.burgerclub.stafftracker.data.model.Employee
import com.burgerclub.stafftracker.databinding.ActivityEmployeeEditBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class EmployeeEditActivity : AppCompatActivity() {

    private lateinit var binding: ActivityEmployeeEditBinding
    private var employeeId: Long = -1L
    private var isFormatting = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEmployeeEditBinding.inflate(layoutInflater)
        setContentView(binding.root)

        employeeId = intent.getLongExtra("employee_id", -1L)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.title = if (employeeId != -1L) "Редактировать" else "Новый сотрудник"

        if (employeeId != -1L) loadEmployee(employeeId)

        // Auto-format time as user types: 1059 → 10:59
        binding.etShiftStart.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (isFormatting) return
                val raw = s.toString().replace(":", "").replace(".", "")
                if (raw.length == 4) {
                    isFormatting = true
                    val formatted = "${raw.substring(0, 2)}:${raw.substring(2, 4)}"
                    binding.etShiftStart.setText(formatted)
                    binding.etShiftStart.setSelection(formatted.length)
                    isFormatting = false
                }
            }
        })

        binding.btnSave.setOnClickListener { saveEmployee() }
    }

    private fun loadEmployee(id: Long) {
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val db = AppDatabase.getDatabase(this@EmployeeEditActivity)
                val emp = db.employeeDao().getEmployee(id) ?: return@launch
                withContext(Dispatchers.Main) {
                    binding.etName.setText(emp.name)
                    binding.etRate.setText(emp.hourlyRate.toInt().toString())
                    binding.etPin.setText(emp.pinCode)
                    binding.etShiftStart.setText(emp.shiftStartTime)
                }
            } catch (e: Exception) {
                Log.e("EmployeeEdit", "Load error", e)
            }
        }
    }

    private fun normalizeTime(input: String): String? {
        // Accept: "10:00", "10.00", "1000", "9:00", "900"
        val digits = input.replace(":", "").replace(".", "").replace(" ", "")
        return when (digits.length) {
            3 -> "${digits[0]}:${digits.substring(1)}" // 900 → 9:00
            4 -> "${digits.substring(0, 2)}:${digits.substring(2)}" // 1000 → 10:00
            else -> if (input.contains(":")) input else null
        }
    }

    private fun saveEmployee() {
        val name = binding.etName.text?.toString()?.trim() ?: ""
        val rateStr = binding.etRate.text?.toString()?.trim() ?: ""
        val pin = binding.etPin.text?.toString()?.trim() ?: ""
        val shiftRaw = binding.etShiftStart.text?.toString()?.trim() ?: ""

        if (name.isEmpty()) { binding.etName.error = "Введите имя"; return }
        if (rateStr.isEmpty()) { binding.etRate.error = "Введите ставку"; return }
        val rate = rateStr.toDoubleOrNull()
        if (rate == null || rate <= 0) { binding.etRate.error = "Некорректная ставка"; return }
        if (pin.length < 4) { binding.etPin.error = "PIN минимум 4 цифры"; return }

        val shiftStart = normalizeTime(shiftRaw)
        if (shiftStart == null) {
            binding.etShiftStart.error = "Введите время: 0900 или 09:00"
            return
        }

        // Validate hours and minutes
        val parts = shiftStart.split(":")
        val hour = parts[0].toIntOrNull() ?: -1
        val min = parts[1].toIntOrNull() ?: -1
        if (hour < 0 || hour > 23 || min < 0 || min > 59) {
            binding.etShiftStart.error = "Некорректное время"
            return
        }

        binding.btnSave.isEnabled = false

        val employee = Employee(
            id = if (employeeId == -1L) 0L else employeeId,
            name = name,
            hourlyRate = rate,
            pinCode = pin,
            shiftStartTime = shiftStart,
            isOnShift = false
        )

        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val db = AppDatabase.getDatabase(this@EmployeeEditActivity)
                if (employeeId == -1L) db.employeeDao().insert(employee)
                else db.employeeDao().update(employee)
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@EmployeeEditActivity,
                        if (employeeId == -1L) "Сотрудник добавлен ✅" else "Сохранено ✅",
                        Toast.LENGTH_SHORT).show()
                    finish()
                }
            } catch (e: Exception) {
                Log.e("EmployeeEdit", "Save error", e)
                withContext(Dispatchers.Main) {
                    binding.btnSave.isEnabled = true
                    Toast.makeText(this@EmployeeEditActivity, "Ошибка: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
}
