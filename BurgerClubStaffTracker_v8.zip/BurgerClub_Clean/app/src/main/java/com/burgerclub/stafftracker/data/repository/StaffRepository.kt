package com.burgerclub.stafftracker.data.repository

import android.content.Context
import androidx.lifecycle.LiveData
import com.burgerclub.stafftracker.data.db.AppDatabase
import com.burgerclub.stafftracker.data.model.Employee
import com.burgerclub.stafftracker.data.model.ShiftRecord
import com.burgerclub.stafftracker.utils.SalaryCalculator
import com.burgerclub.stafftracker.utils.NotificationHelper
import java.util.Calendar

class StaffRepository(private val context: Context) {

    private val db = AppDatabase.getDatabase(context)
    private val employeeDao = db.employeeDao()
    private val shiftDao = db.shiftRecordDao()

    // Employees
    fun getAllEmployees(): LiveData<List<Employee>> = employeeDao.getAllEmployees()
    suspend fun getAllEmployeesList(): List<Employee> = employeeDao.getAllEmployeesList()
    suspend fun getEmployee(id: Long): Employee? = employeeDao.getEmployee(id)
    suspend fun insertEmployee(employee: Employee): Long = employeeDao.insert(employee)
    suspend fun updateEmployee(employee: Employee) = employeeDao.update(employee)
    suspend fun deleteEmployee(employee: Employee) = employeeDao.delete(employee)

    // Shifts
    fun getAllRecords(): LiveData<List<ShiftRecord>> = shiftDao.getAllRecords()
    fun getRecordsByDateRange(from: Long, to: Long): LiveData<List<ShiftRecord>> =
        shiftDao.getRecordsByDateRange(from, to)

    suspend fun getAllRecordsList(): List<ShiftRecord> = shiftDao.getAllRecordsList()

    suspend fun checkIn(employee: Employee, photoPath: String?): Result<ShiftRecord> {
        val openShift = shiftDao.getOpenShift(employee.id)
        if (openShift != null) {
            return Result.failure(Exception("already_checked_in"))
        }

        val now = System.currentTimeMillis()
        val cal = Calendar.getInstance().apply { timeInMillis = now }
        val parts = employee.shiftStartTime.split(":")
        val shiftHour = parts[0].toIntOrNull() ?: 0
        val shiftMin = parts[1].toIntOrNull() ?: 0

        val shiftStartCal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, shiftHour)
            set(Calendar.MINUTE, shiftMin)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        val diffMinutes = ((now - shiftStartCal.timeInMillis) / 60000).toInt()
        val isLate = diffMinutes > 10
        val lateMinutes = if (isLate) diffMinutes else 0

        if (isLate) {
            NotificationHelper.sendLateNotification(context, employee.name, lateMinutes)
        }

        val record = ShiftRecord(
            employeeId = employee.id,
            employeeName = employee.name,
            checkInTime = now,
            checkInPhotoPath = photoPath,
            isLate = isLate,
            lateMinutes = lateMinutes
        )
        val id = shiftDao.insert(record)
        employeeDao.updateShiftStatus(employee.id, true)
        return Result.success(record.copy(id = id))
    }

    suspend fun checkOut(employee: Employee, photoPath: String?): Result<ShiftRecord> {
        val openShift = shiftDao.getOpenShift(employee.id)
            ?: return Result.failure(Exception("not_checked_in"))

        val now = System.currentTimeMillis()
        val billedHours = SalaryCalculator.calcBilledHours(openShift.checkInTime, now)
        val salary = billedHours * employee.hourlyRate

        val updated = openShift.copy(
            checkOutTime = now,
            checkOutPhotoPath = photoPath,
            billedHours = billedHours,
            salary = salary
        )
        shiftDao.update(updated)
        employeeDao.updateShiftStatus(employee.id, false)
        return Result.success(updated)
    }

    suspend fun getOpenShift(employeeId: Long): ShiftRecord? = shiftDao.getOpenShift(employeeId)

    data class EmployeeRating(
        val employee: Employee,
        val totalHours: Double,
        val lateCount: Int,
        val score: Double
    )

    suspend fun getRatings(): List<EmployeeRating> {
        val employees = employeeDao.getAllEmployeesList()
        return employees.map { emp ->
            val hours = shiftDao.getTotalHours(emp.id) ?: 0.0
            val lates = shiftDao.getLateCount(emp.id)
            val score = hours - (lates * 2.0)
            EmployeeRating(emp, hours, lates, score)
        }.sortedByDescending { it.score }
    }
}
