package com.burgerclub.stafftracker.data.db

import androidx.lifecycle.LiveData
import androidx.room.*
import com.burgerclub.stafftracker.data.model.ShiftRecord

@Dao
interface ShiftRecordDao {

    @Query("SELECT * FROM shift_records ORDER BY checkInTime DESC")
    fun getAllRecords(): LiveData<List<ShiftRecord>>

    @Query("SELECT * FROM shift_records ORDER BY checkInTime DESC")
    suspend fun getAllRecordsList(): List<ShiftRecord>

    @Query("SELECT * FROM shift_records WHERE employeeId = :empId ORDER BY checkInTime DESC")
    suspend fun getRecordsForEmployee(empId: Long): List<ShiftRecord>

    @Query("SELECT * FROM shift_records WHERE checkInTime BETWEEN :from AND :to ORDER BY checkInTime DESC")
    fun getRecordsByDateRange(from: Long, to: Long): LiveData<List<ShiftRecord>>

    @Query("SELECT * FROM shift_records WHERE employeeId = :empId AND checkOutTime IS NULL LIMIT 1")
    suspend fun getOpenShift(empId: Long): ShiftRecord?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(record: ShiftRecord): Long

    @Update
    suspend fun update(record: ShiftRecord)

    @Delete
    suspend fun delete(record: ShiftRecord)

    @Query("SELECT COUNT(*) FROM shift_records WHERE employeeId = :empId AND isLate = 1")
    suspend fun getLateCount(empId: Long): Int

    @Query("SELECT SUM(billedHours) FROM shift_records WHERE employeeId = :empId AND checkOutTime IS NOT NULL")
    suspend fun getTotalHours(empId: Long): Double?
}
