package com.burgerclub.stafftracker.utils

import java.util.Calendar
import kotlin.math.floor

object SalaryCalculator {

    /**
     * Late logic: if arrived more than 10 min past any round hour → late
     * e.g. 9:11 → late (11 min past 9:00)
     *      9:05 → not late (5 min past 9:00)
     *      10:15 → late (15 min past 10:00)
     */
    fun isLate(checkInMillis: Long): Boolean {
        val cal = Calendar.getInstance().apply { timeInMillis = checkInMillis }
        val minutes = cal.get(Calendar.MINUTE)
        return minutes > 10
    }

    fun lateMinutes(checkInMillis: Long): Int {
        val cal = Calendar.getInstance().apply { timeInMillis = checkInMillis }
        val minutes = cal.get(Calendar.MINUTE)
        return if (minutes > 10) minutes else 0
    }

    /**
     * Billing rules:
     * - Check-in: if arrived after :10 → bill from next full hour
     *   e.g. 9:19 → bill from 10:00
     *        9:05 → bill from 9:00
     * - Check-out: always floor to last full hour
     *   e.g. 21:50 → bill until 21:00
     *        22:10 → bill until 22:00
     */
    fun calcBilledHours(checkInMillis: Long, checkOutMillis: Long): Double {
        val inCal = Calendar.getInstance().apply { timeInMillis = checkInMillis }
        val outCal = Calendar.getInstance().apply { timeInMillis = checkOutMillis }

        val inMinutes = inCal.get(Calendar.MINUTE)
        val startHour = if (inMinutes > 10) {
            inCal.get(Calendar.HOUR_OF_DAY) + 1
        } else {
            inCal.get(Calendar.HOUR_OF_DAY)
        }

        val endHour = outCal.get(Calendar.HOUR_OF_DAY)

        val inDay = inCal.get(Calendar.DAY_OF_YEAR)
        val outDay = outCal.get(Calendar.DAY_OF_YEAR)
        val dayDiff = outDay - inDay

        val totalHours = (dayDiff * 24 + endHour - startHour).toDouble()
        return if (totalHours < 0) 0.0 else totalHours
    }

    fun formatHours(hours: Double): String {
        val h = floor(hours).toInt()
        val m = ((hours - h) * 60).toInt()
        return if (m > 0) "${h}ч ${m}м" else "${h}ч"
    }
}
