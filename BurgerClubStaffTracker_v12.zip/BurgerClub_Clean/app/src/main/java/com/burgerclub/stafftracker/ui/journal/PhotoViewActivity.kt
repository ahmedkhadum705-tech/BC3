package com.burgerclub.stafftracker.ui.journal

import android.graphics.BitmapFactory
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.burgerclub.stafftracker.databinding.ActivityPhotoViewBinding
import java.io.File

class PhotoViewActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPhotoViewBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPhotoViewBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.title = "Фото смены"

        val inPath = intent.getStringExtra("photo_in")
        val outPath = intent.getStringExtra("photo_out")

        if (inPath != null && File(inPath).exists()) {
            binding.ivCheckIn.setImageBitmap(BitmapFactory.decodeFile(inPath))
            binding.cardCheckIn.visibility = View.VISIBLE
        } else {
            binding.cardCheckIn.visibility = View.GONE
        }

        if (outPath != null && File(outPath).exists()) {
            binding.ivCheckOut.setImageBitmap(BitmapFactory.decodeFile(outPath))
            binding.cardCheckOut.visibility = View.VISIBLE
        } else {
            binding.cardCheckOut.visibility = View.GONE
        }
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
}
