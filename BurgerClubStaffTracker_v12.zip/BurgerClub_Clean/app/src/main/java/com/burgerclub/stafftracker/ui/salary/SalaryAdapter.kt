package com.burgerclub.stafftracker.ui.salary

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.burgerclub.stafftracker.databinding.ItemSalaryBinding
import com.burgerclub.stafftracker.utils.SalaryCalculator

class SalaryAdapter : ListAdapter<SalaryActivity.EmployeeSalarySummary, SalaryAdapter.VH>(DIFF) {

    inner class VH(private val b: ItemSalaryBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(item: SalaryActivity.EmployeeSalarySummary) {
            val ctx = b.root.context
            b.tvName.text = item.employee.name
            b.tvShifts.text = "Смен: ${item.shiftsCount}"
            b.tvHours.text = SalaryCalculator.formatHours(item.totalHours)
            b.tvRate.text = "${item.employee.hourlyRate.toInt()} ₽/ч"
            b.tvSalary.text = "${String.format("%,.0f", item.totalSalary)} ₽"
            b.tvLate.text = if (item.lateCount > 0) "⚠ ${item.lateCount} опозд." else "✓ Без опозданий"
            b.tvLate.setTextColor(
                if (item.lateCount > 0)
                    ctx.getColor(com.burgerclub.stafftracker.R.color.accent_yellow)
                else
                    ctx.getColor(com.burgerclub.stafftracker.R.color.accent_green)
            )
            // Progress bar: salary relative to max in list
            if (item.totalSalary > 0) {
                b.salaryBar.visibility = android.view.View.VISIBLE
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val b = ItemSalaryBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(b)
    }

    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(getItem(position))

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<SalaryActivity.EmployeeSalarySummary>() {
            override fun areItemsTheSame(a: SalaryActivity.EmployeeSalarySummary, b: SalaryActivity.EmployeeSalarySummary) = a.employee.id == b.employee.id
            override fun areContentsTheSame(a: SalaryActivity.EmployeeSalarySummary, b: SalaryActivity.EmployeeSalarySummary) = a == b
        }
    }
}
