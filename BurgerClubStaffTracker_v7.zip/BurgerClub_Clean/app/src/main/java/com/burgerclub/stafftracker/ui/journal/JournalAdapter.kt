package com.burgerclub.stafftracker.ui.journal

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.burgerclub.stafftracker.data.model.ShiftRecord
import com.burgerclub.stafftracker.databinding.ItemJournalBinding
import com.burgerclub.stafftracker.utils.DateUtils
import com.burgerclub.stafftracker.utils.SalaryCalculator

class JournalAdapter(
    private val onPhotoClick: (ShiftRecord) -> Unit
) : ListAdapter<ShiftRecord, JournalAdapter.VH>(DIFF) {

    inner class VH(private val b: ItemJournalBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(r: ShiftRecord) {
            b.tvEmployee.text = r.employeeName
            b.tvCheckIn.text = "Вход: ${DateUtils.formatTimestamp(r.checkInTime)}"
            b.tvCheckOut.text = if (r.checkOutTime != null)
                "Выход: ${DateUtils.formatTimestamp(r.checkOutTime)}" else "Выход: —"
            b.tvHours.text = "Часы: ${SalaryCalculator.formatHours(r.billedHours)}"
            b.tvSalary.text = "Зарплата: ${String.format("%.0f", r.salary)} руб"
            b.tvLate.text = if (r.isLate) "⚠ Опоздание: ${r.lateMinutes} мин" else "✅ Вовремя"
            b.tvLate.setTextColor(
                if (r.isLate) b.root.context.getColor(com.burgerclub.stafftracker.R.color.yellow_warning)
                else b.root.context.getColor(com.burgerclub.stafftracker.R.color.green_success)
            )
            b.btnPhotos.setOnClickListener { onPhotoClick(r) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val b = ItemJournalBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(b)
    }

    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(getItem(position))

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<ShiftRecord>() {
            override fun areItemsTheSame(a: ShiftRecord, b: ShiftRecord) = a.id == b.id
            override fun areContentsTheSame(a: ShiftRecord, b: ShiftRecord) = a == b
        }
    }
}
